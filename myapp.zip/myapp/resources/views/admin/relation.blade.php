    @include('admin-template/header')


      <!--main content start-->
     <section id="main-content">
          <section class="wrapper site-min-height">
              <!-- page start-->
              <section class="panel">
                  <header class="panel-heading">
                      List Of Children Under You 
                  </header>
                     <div class="modal fade " id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                      <div class="modal-content">
                                          <div class="modal-header">
                                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                              <h4 class="modal-title">Add Child</h4>
                                          </div>

                                             <!-- editform -->
                                            <form class="pannel-body" id="frmchild" action="/addchild" method="POST">
                                                @csrf
                                                    <div class="modal-body">
                                                    <select class="form-control form-select-sm" name="users" id="users">
                                                    <option><p>Select Childs</p></option>
                                                    </select>
                                            <!-- editform  -->
                                            </div>
                                          <div class="modal-footer">
                                              <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                                              <button class="btn btn-success" type="submit">Save changes</button>
                                          </div>
                                              </form>

                                      </div>
                                  </div>
                              </div>
                  <div class="panel-body">
                      <div class="adv-table editable-table ">
                          <div class="clearfix">
                              <div class="btn-group">
                                  <div class="btn-group">
                                      <a id="add_child" role="button" class="btn btn-secondary disabled" href="#myModal" data-toggle="modal">Add Children</a>
                                  </div>
                              </div>
                              <div class="btn-group pull-right">
                                  <ul class="dropdown-menu pull-right">
                                      <li><a href="#">Print</a></li>
                                      <li><a href="#">Save as PDF</a></li>
                                      <li><a href="#">Export to Excel</a></li>
                                  </ul>
                              </div>
                          </div>
                          <div class="space12"></div>

                          <!-- <div class=""> -->
                          <div class="table-responsive">

                          <table class="table table-striped table-hover table-bordered" id="editable-sample">
                              <thead>
                              <tr>
                                  <th></th>
                                  <th>id</th>
                                  <th>name</th>
                                  <th>email</th>
                                  <th>status</th>
                              </tr>
                              </thead>
                              <tbody>
                          </tbody>
                          </table>

                          </div>
                      </div>
                  </div>
              </section>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
    @include('admin-template/footer')

  </section>

    <!-- js placed at the end of the document so the pages load faster -->
  <script src="js/jquery.js"></script>
    <script src="js/jquertruey-ui-1.9.2.custom.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <!-- <script type="text/javascript" src="assets/data-tables/jquery.dataTables.js"></script> -->
    <script type="text/javascript" src="assets/data-tables/DT_bootstrap.js"></script>
    <script src="js/respond.min.js" ></script>

  <!--right slidebar-->
  <script src="js/slidebars.min.js"></script>

    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

      <!--script for this page only-->
      <script src="js/editable-table.js"></script>

      <!--script for toggle Button-->
<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>

      <!-- END JAVASCRIPTS -->
      <script>

        function format ( d ) {
            // return d;
            // console.log(d);
            var str = "";
            str += "<table class='table table-bordered'><tbody>";
            for(x in d['child'])
            {
                    str +='<tr>'+
                            '<td>Child : '+x+'</td>'+
                            '<td>'+d['child'][x].id+'</td>'+
                            '<td>'+d['child'][x].name+'</td>'+
                            '<td>'+d['child'][x].email+'</td>'+
                            '<td>'+d['child'][x].status+'</td></tr>';
                            
                // console.log(d['child'][x].id);           
                // console.log(d['child'][x].name); 
                // str +=  ''+d['child'][x].id+' name: '+d['child'][x].name+' email: '+d.email+' status: '+d.child[0].status+'<br>';        

            }
            str += "</tbody></table>";


            return str;
            // return 'Full name: '+d.name+' '+d.email+'<br>'+
            //     'Salary: '+d.child[0].name+'<br>'+
            //     'The child row can contain any data you wish, including links, images, inner tables etc.';
        }
          $(document).ready(function() {
            var token = "<?php echo csrf_token() ?>";
              var table = $('#editable-sample').DataTable({
                   "paging":   true,
                  "processing": true,
                  "serverSide": true,
                  "searching": false,
                    "ajax": {
                        "url": "/parents",
                        "type":"post" ,
                        "data":{
                          "_token":token
                        }
                    },
                     "language": {
                        "search": "_INPUT_", 
                                "searchPlaceholder": "Search"   // Placeholder for the search box

                    },
                 "aLengthMenu": [
                        [5, 15, 20, -1],
                        [5, 15, 20, "ALL"]
                    ],
                     "columns": [
                     {
                            data: null, 
                            className: "dt-center morebtn",
                            // defaultContent: '<i class="fa fa-pencil"/>',
                            defaultContent: "<i class='fa fa-lg fa-chevron-circle-down'></i>",
                            orderable: false
                      },
                      { "data": "id" },
                      { "data": "name" },
                      { "data": "email" },
                      { "data": "status" },
                       

                    ]
              });

            var detailRows = [];

            $('#editable-sample tbody').on( 'click', 'tr td.morebtn', function () {   

                var tr = $(this).closest('tr');
                var row = table.row( tr );
                var idx = $.inArray( tr.attr('id'), detailRows );
                if ( row.child.isShown() ) 
                {
                    tr.removeClass( 'details' );
                    row.child.hide();
         
                    // Remove from the 'open' array
                    detailRows.splice( idx, 1 );
                }
                 else 
                 {
                    tr.addClass( 'details' );
                    row.child( format( row.data() ) ).show();
         
                    // Add to the 'open' array
                    if ( idx === -1 ) {
                        detailRows.push( tr.attr('id') );
                    }
                }

            });

             table.on( 'draw', function () {
                $.each( detailRows, function ( i, id ) {
                    $('#'+id+' td.morebtn').trigger( 'click' );
                } );
            } );

              // EditableTable.init();
          });
      </script>
  </body>

<!-- Mirrored from thevectorlab.net/flatlab/editable_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Dec 2017 10:19:07 GMT -->
</html>
