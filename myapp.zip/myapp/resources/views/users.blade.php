    @include('admin-template/header')


      <!--main content start-->
     <section id="main-content">
          <section class="wrapper site-min-height">
              <!-- page start-->
              <section class="panel">
                  <header class="panel-heading">
                      List Users 
                  </header>
                   <!--   <div class="modal fade " id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                      <div class="modal-content">
                                          <div class="modal-header">
                                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                              <h4 class="modal-title">Edit User</h4>
                                          </div>
                                          <div class="modal-body">

                                             editform
                                            <form class="pannel-body" id="reg_form" action="/regestration" method="POST">
                                                @csrf
                                                    <input type="text" class="form-control" name="userName" placeholder="Full Name" autofocus>
                                                    <input type="text" class="form-control" name="emailId" placeholder="Email" autofocus>
                                              </form>
                                            editform 

                                          </div>
                                          <div class="modal-footer">
                                              <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                                              <button class="btn btn-success" data-dismiss="modal" type="button">Save changes</button>
                                          </div>
                                      </div>
                                  </div>
                              </div> -->
                  <div class="panel-body">
                      <div class="adv-table editable-table ">
                          <div class="clearfix">
                              <div class="btn-group">
                                   <div class="btn-group">
                                      <input type="text" name="filtermail" autocomplete="off" id="filter" placeholder="Email" class="form-control">
                                  </div>
                                  <div class="btn-group">
                                    
                                      <button id="emailfilter" type="button" class="btn btn-secondary">search</button>
                                  </div>
                              </div>
                              <div class="btn-group pull-right">
                                  <ul class="dropdown-menu pull-right">
                                      <li><a href="#">Print</a></li>
                                      <li><a href="#">Save as PDF</a></li>
                                      <li><a href="#">Export to Excel</a></li>
                                  </ul>
                              </div>
                          </div>
                          <div class="space12"></div>

                          <!-- <div class=""> -->
                          <div class="table-responsive">

                          <table class="table table-striped table-hover table-bordered" id="editable-sample">
                              <thead>
                              <tr>
                                  <th>id</th>
                                  <th>name</th>
                                  <th>email</th>
                                  <th>status</th>
                                  <!-- <th>edit</th> -->
                                  <th>delete</th>
                              </tr>
                              </thead>
                              <tbody>
                          </tbody>
                          </table>

                          </div>
                      </div>
                  </div>
              </section>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
    @include('admin-template/footer')

  </section>

    <!-- js placed at the end of the document so the pages load faster -->
  <script src="js/jquery.js"></script>
    <script src="js/jquertruey-ui-1.9.2.custom.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <!-- <script type="text/javascript" src="assets/data-tables/jquery.dataTables.js"></script> -->
    <script type="text/javascript" src="assets/data-tables/DT_bootstrap.js"></script>
    <script src="js/respond.min.js" ></script>

  <!--right slidebar-->
  <script src="js/slidebars.min.js"></script>

    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

      <!--script for this page only-->
      <script src="js/editable-table.js"></script>

      <!--script for toggle Button-->
<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>

      <!-- END JAVASCRIPTS -->
      <script>
          $(document).ready(function() {
            var token = "<?php echo csrf_token() ?>";
              var table = $('#editable-sample').DataTable({
                   "paging":   true,
                  "processing": true,
                  "serverSide": true,
                  "searching": false,
                    "ajax": {
                        "url": "/users",
                        "type":"post" ,
                        "data":{
                          "_token":token
                        }
                    },
                     "language": {
                        "search": "_INPUT_", 
                                "searchPlaceholder": "Search"   // Placeholder for the search box

                    },
                 "aLengthMenu": [
                        [5, 15, 20, -1],
                        [5, 15, 20, "ALL"]
                    ],
                     "columns": [
                        { "data": "id" },
                        { "data": "name" },
                        { "data": "email" },
                        { "data": "status" },
                         {
                            data: null, 
                            className: "dt-center del_btn",
                            // defaultContent: '<i class="fa fa-pencil"/>',
                            defaultContent: "<a class='btn btn-light' href='#'><i  class='fa fa-lg fa-trash-o'></i>"+
                            "</a>",
                            orderable: false
                        },

                    ]
              });

               $("#emailfilter").click(function(e){
                $("#editable-sample tbody > tr").children().remove();
                if($("#filter").val()==" ")
                {
                    // table.ajax.reload();
                    console.log('empty');
                }
                else
                {
                    $.ajax({
                            type: "POST", 
                            url: "/filterByemail", 
                            dataType: "json",
                            data: {
                                _token:token,
                                email : $("#filter").val(),
                                },
                            success: function(response) 
                            {
                                trHTML = '';
                                $.each(response, function (i, item) {
                                    trHTML += '<tr><td>' + item.id + 
                                          '</td><td>' + item.name +
                                          '</td><td>' + item.email + 
                                          '</td><td>' + item.status + 
                                            "</td><td><a class='btn btn-light' href='#'><i  class='fa fa-lg fa-trash-o'></i></a></td></tr>";
                                });
                              $('#editable-sample').append(trHTML);

                                  // console.log(response);
                             },
                            error:function(e)
                            {
                                alert(e);    
                                console.log(e);
                            }
                        });
                }
            });
           
              //  $.ajax({
              //     type: "post", 
              //     url: "/users", 
              //     data:{
              //       _token:token,
              //     },
              //     dataType: "json",
              //     success: function(response) 
              //     {
              //           // $.each(response, function (i, item) 
              //           // {
              //           //     var del = '<a id="del-btn" class="justify-content-center" name="'+item.id+'" href="#">'+
              //           //         "<i  class='fa fa-lg fa-trash-o'></i>"+
              //           //         '</a>';

              //           //     // var edit='<a id="edit-btn" class="pl-5" data-toggle="modal" name="'+item.id+'" href="#myModal">'+
              //           //     // "<i  class='fa fa-ln fa-pencil'></i>"+
              //           //     // '</a>';
              //           //     table.row.add([item.id,item.name,item.email,item.status,del]).draw();
              //           });
              //           // $('a[id="edit-btn"]').click(function(e){
              //           //     alert($(this).attr('name'));
              //           // });

              //           $('a[id="del-btn"]').click(function(e){
              //                if(confirm("Are u sure you want to delete!"))
              //               {
              //                   // var id=$(this).attr('name');
              //                   var $this=$(this);
              //                    $.ajax({
              //                     type: "post", 
              //                     url: "/del_users", 
              //                     data:{
              //                       _token:token,
              //                       id:$this.attr('name'),
              //                     },
              //                     dataType: "json",
              //                     success: function(response) 
              //                     {
              //                        table
              //                           .row( $this.parent().parent('tr'))
              //                           .remove()
              //                           .draw();
              //                       console.log(response);
              //                     },
              //                     error:function(e)
              //                     {
              //                         console.log(e);
              //                     }
              //                   });
              //               }
                                
              //           });


              //     },
              //     error:function(e)
              //     {
              //         console.log(e);
              //     }
                      
              // });

              
           

              // EditableTable.init();
          });
      </script>
  </body>

<!-- Mirrored from thevectorlab.net/flatlab/editable_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Dec 2017 10:19:07 GMT -->
</html>
