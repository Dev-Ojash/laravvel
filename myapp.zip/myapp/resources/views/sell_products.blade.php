    @include('template/header')


      <!--main content start-->
     <section id="main-content">
          <section class="wrapper site-min-height">
              <!-- page start-->
              <section class="panel">
                  <header class="panel-heading">
                      Sell Products 
                  </header>
                  <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                         
                          <div class="panel-body">
                              <form role="form" name='sell-form' method="post" action="/sellproduct">
                                      @csrf

                                  <div class="form-group">
                                      <label for="exampleInputPassword1">Select Product To Sell</label>
                                           <select class="form-control m-bot15" name='product'>
                                              <option>Select Product</option>
                                    @foreach ($products as $product)
                                              <option>{{ $product->name }}</option>

                                    @endforeach                                      
                                          </select>
                                  </div>
                                  <div class="checkbox">
                                      <label>
                                          <input type="checkbox" name='check'> 
                                          <label for="exampleInputPassword1">You Want To Sell?</label>
                                      </label>
                                  </div>
                                  <button type="submit" class="btn btn-success">Submit</button>
                                  <a type="button" href="/products" class="btn btn-info">Exit</a>

                              </form>

                          </div>
                      </section>
                  </div>
              </section>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
    @include('template/footer')

  </section>

    <!-- js placed at the end of the document so the pages load faster -->
  <script src="js/jquery.js"></script>
    <script src="js/jquertruey-ui-1.9.2.custom.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <!-- <script type="text/javascript" src="assets/data-tables/jquery.dataTables.js"></script> -->
    <script type="text/javascript" src="assets/data-tables/DT_bootstrap.js"></script>
    <script src="js/respond.min.js" ></script>

  <!--right slidebar-->
  <script src="js/slidebars.min.js"></script>

    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

      <!--script for this page only-->

      <!--script for toggle Button-->

      <!-- END JAVASCRIPTS -->
      <script>
      </script>
  </body>

<!-- Mirrored from thevectorlab.net/flatlab/editable_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Dec 2017 10:19:07 GMT -->
</html>
