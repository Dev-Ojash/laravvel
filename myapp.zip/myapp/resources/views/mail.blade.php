<table>
    <tr>
        <td>Hello {{ $name }}.</td>
    </tr>
    <tr>
        <td>{{ $uname }} is refer you to use flatlab chain System</td>
    </tr>
    <tr>
        <td>Click the below Link to Sign up</td>
		<a href="{{ url('/regestration') }}">Click me!</a>
    </tr>

</table>