{!! Form::open(array('url' => '/show')) !!}
    // Other inputs...
    {!! no_captcha()->display() !!}
    {!! Form::submit('Submit') !!}
{!! Form::close() !!}

// Remember what your mother told you
{!! no_captcha()->script() !!}