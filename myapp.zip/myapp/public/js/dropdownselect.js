$(function () {  

$('#country').on('change', function() {

	// $.ajax({url: "<?php echo base_url()?>getstate", data:{"country" : this.value}});
  // alert( this.value );
});

})

