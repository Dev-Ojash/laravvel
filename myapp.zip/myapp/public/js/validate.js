$(function () {  

var $frm = $("#login_form");
if($frm.length){

	$frm.validate({
		rules:{
			email_id:{
				required: true,
				email :true
			},
			password:{
				required: true
			}
			
		},
		messages:{
			email_id:{
				required:'* User Id is required!',
				email: '* Please enter a valid Email!'
			},
			password:{
				required: '* Password is required!'
			}
		}		
	})
};



var $rfrm = $("#reg_form");

if($rfrm.length){

	$rfrm.validate({
		rules:{
			userName:{
				required: true
			},
			emailId:{
				required: true,
				email: true
			},
			password:{
				required: true
			},
			
		},
		messages:{
			userName:{
				required:'* User name is required!'
			},
			password:{
				required: '* Password is required!'
			},
			emailId:{
				required: '* Email is required!',
				email: '* Please enter a valid Email!',
			},
		}		
	})
};


var $pfrm = $("#personal_form");

if($pfrm.length){
    $pfrm.validate({
        rules:{
            user_name:{
                required: true
            },
            user_email:{
                required: true,
                email: true
            },
            old_password:{
                required: true
            },
            new_password:{
                required: true
            }
            
        },
        messages:{
            user_name:{
                required:'* User name is required!'
            },
            user_email:{
                required: '* Email is required!',
                email: '* Please enter a valid Email!'
            },
            old_password:{
                required: '* Old Password is required!'
            },
            new_password:{
                required: '* New Password is required!'
            },
        },



});
}
});