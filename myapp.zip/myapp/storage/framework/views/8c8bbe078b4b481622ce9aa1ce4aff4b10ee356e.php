<table>
    <tr>
        <td>Hello <?php echo e($name); ?>.</td>
    </tr>
    <tr>
        <td><?php echo e($uname); ?> is refer you to use flatlab chain System</td>
    </tr>
    <tr>
        <td>Click the below Link to Sign up</td>
		<a href="<?php echo e(url('/regestration')); ?>">Click me!</a>
    </tr>

</table><?php /**PATH C:\laravel Projects\myapp\resources\views/mail.blade.php ENDPATH**/ ?>