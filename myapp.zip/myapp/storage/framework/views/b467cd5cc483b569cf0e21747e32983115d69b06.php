<?php echo Form::open(array('url' => '/show')); ?>

    // Other inputs...
    <?php echo no_captcha()->display(); ?>

    <?php echo Form::submit('Submit'); ?>

<?php echo Form::close(); ?>


// Remember what your mother told you
<?php echo no_captcha()->script(); ?><?php /**PATH C:\laravel Projects\myapp\resources\views/temp.blade.php ENDPATH**/ ?>