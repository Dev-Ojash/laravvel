    <?php echo $__env->make('template/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 
          <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
                <div class="modal fade " id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                      <div class="modal-content">
                                          <div class="modal-header">
                                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                              <h4 class="modal-title">Refer a friend</h4>
                                          </div>

                                             <!-- editform -->
                                            <form class="pannel-body" id="frmchild" action="/refer" method="POST">
                                                <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                    <div class="panel-body">
                              <form role="form">
                                  <div class="form-group">
                                      <label for="exampleInputEmail1">Email address</label>
                                      <input type="email" name='email' class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                                  </div>
                                  <div class="form-group">
                                      <label for="name">Name</label>
                                      <input type="text" name='name' class="form-control" id="name" placeholder="Name">
                                  </div>

                          </div>
                                            <!-- editform  -->
                                            </div>
                                          <div class="modal-footer">
                                              <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                                              <button class="btn btn-success" type="submit">Submit</button>
                                          </div>
                                              </form>

                                      </div>
                                  </div>
                              </div>
              <div class="row profile-content">
                  <aside class="profile-nav col-lg-3">
                      <section class="panel">
                          <div class="user-heading round">
                              <a href="#">
                                  <img src="img/profile-avatar.jpg" alt="">
                              </a>
                            
                          </div>

                          <ul class="nav nav-pills nav-stacked">
                              <li><a id="info" href="#"> <i class="fa fa-user"></i> Profile</a></li>
                              <li><a id="edit" href="#"> <i class="fa fa-edit"></i> Edit profile</a></li>
                               <li><a id="refer" data-toggle="modal" href="#myModal" role="button"> <i class="fa fa-users"></i> Refer to a friend</a></li>
                                <li><a href="/logout" onclick="return confirm('are you sure you want to logout?')"> <i class="fa fa-unlock-alt"></i>Logout</a></li>
                          </ul>

                      </section>
                  </aside>
                  <aside class="profile-info col-lg-9">
                      <section class="panel">
                          <div class="bio-graph-heading">
                              Welcome to the profile 
                          </div>
                              <h1>Bio Graph</h1>
                    <div class="panel-body bio-graph-info">

                          <div class="row">
                                  <div class="bio-row">
                                      <p><span>First Name </span>: <?php echo e($name); ?></p>
                                  </div>
                                  <div class="bio-row">
                                      <p><span>Email </span>: <?php echo e($email); ?></p>
                                  </div>
                                  <div class="bio-row">
                                      <p><span>Total Earning </span>:   <i class="fa fa-rupee"></i><?php echo e($total_amount); ?></p>
                                  </div>
                                  <div class="bio-row">
                                      <p><span>Last Amount </span>:   <i class="fa fa-rupee"></i><?php echo e($last_amount); ?></p>
                                  </div>
                              </div>
                            </div>
                      </section>
                      </aside>
                      <aside class="profile-edit col-lg-9">
                        <section class="panel">
                          <div class="bio-graph-heading">
                                 Welcome to the edit profile.
                          </div>
                          <div class="panel-body bio-graph-info">
                              <h1> Profile Info</h1>
                              <form class="form-horizontal" id="personal_form" method="post" action="/profile" >
                                <?php echo csrf_field(); ?>
                                  <div class="form-group">
                                      <label  class="col-lg-2 control-label">Name <strong>*</strong></label>
                                      <div class="col-lg-6">
                                          <input type="text" name="user_name" value="<?php echo e($name); ?>" class="form-control" id="f-name" placeholder=" ">
                                      </div>
                                  </div>
                                 

                                  <div class="form-group">
                                      <label  class="col-lg-2 control-label">Email <strong>*</strong></label>
                                      <div class="col-lg-6">
                                          <input type="text" name="user_email" value="<?php echo e($email); ?>" class="form-control" id="b-day" placeholder=" ">
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label  class="col-lg-2 control-label">old password <strong>*</strong></label>
                                      <div class="col-lg-6">
                                          <input type="text" name="old_password"  class="form-control" id="c-name" placeholder=" ">
                                      </div>
                                  </div>
                                 <div class="form-group">
                                      <label  class="col-lg-2 control-label">new password <strong>*</strong></label>
                                      <div class="col-lg-6">
                                          <input type="password" name="new_password" class="form-control" id="c-name2" placeholder=" ">
                                      </div>
                                  </div>
                                      <div class="form-group">
                                      <div class="col-lg-offset-2 col-lg-10">
                                          <input type="submit" class="btn btn-success" value=Save>
                                          <!-- <button type="submit" class="btn btn-success">Save</button> -->
                                      </div>
                                  </div>

                              </form>
                          </div>
                      </section>
                      </aside>
              </div>

              <!-- page end-->
          </section>
      </section>
      <!--main content end-->

  
    <?php echo $__env->make('template/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </section>

    <!-- js placed at the end of the document so the pages load faster -->
     <script src="js/jquery.js"></script>
    <script src="js/jquertruey-ui-1.9.2.custom.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <!-- <script type="text/javascript" src="assets/data-tables/jquery.dataTables.js"></script> -->
    <script type="text/javascript" src="assets/data-tables/DT_bootstrap.js"></script>
    <script src="js/respond.min.js" ></script>

  <!--right slidebar-->
  <script src="js/slidebars.min.js"></script>

    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

      <!--script for this page only-->
      <script src="js/editable-table.js"></script>

      <!--script for toggle Button-->
<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
    <!--common script for all pages-->

  <script>
  $(window).load(function(){
       $('.profile-edit').hide();
       $('#edit').click(function () {
            $('.profile-info').hide(300);
            $('.profile-edit').show(1000);

       });
        $('#info').click(function () {
            $('.profile-info').show(1000);
            $('.profile-edit').hide(300);
       });

        if("<?php echo e(session('msg')); ?>")
        {
            alert('<?php echo e(session('msg')); ?>');

        }

        

              
          });
    
  </script>


  </body>

<!-- Mirrored from thevectorlab.net/flatlab/profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Dec 2017 10:19:38 GMT -->
</html>
<?php /**PATH C:\laravel Projects\myapp\resources\views/profile.blade.php ENDPATH**/ ?>