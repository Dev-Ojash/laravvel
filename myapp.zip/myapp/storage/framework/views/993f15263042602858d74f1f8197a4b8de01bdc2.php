 <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
              2021 &copy; FlatLab by VectorLab.
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end--><?php /**PATH C:\laravel Projects\myapp\resources\views/template/footer.blade.php ENDPATH**/ ?>