<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Mail;
class products extends Controller
{
    public function index(Request $req)
    {
        $data = ['name' => 'ojash', 'data' => 'ojash patel'];
        $user['to'] ='ojash7560@gmail.com';
        Mail::send('mail',$data,function($message) use ($user)
        {
            $message->to($user['to']);
            $message->subject('hello oju');
            # code...
        });
    }

    public function products()
    {
    	return view('products');
    }

    public function list_products()
    {
        $limit = intval(request("length"));
        $offset = intval(request("start"));

        $data = DB::table('product')->select('id','name','price','status')->where('status','available')->offset($offset)->limit($limit)->get();
        $count = DB::table('product')->select('*')->get();

        // echo count($data);
        $response = array(
               "draw" => intval(request("draw")),
               "lenth" => $limit,
               "start" => $offset,
               "iTotalRecords" => count($count),
               "iTotalDisplayRecords" =>count($count),
               "aaData" => $data
            );
        echo json_encode($response);
    }

    public function load_sell_products(Request $req)			
    {
        $data = DB::table('product')->select('name')->where('status','available')->get();

    	return view('sell_products',['products' =>$data]);

    }
    public function sell_product(Request $req)
    {
    	$product = request('product');
        $uid = session('userID');
    	$check = request('check');
    	if($check)
    	{
    		$id = DB::table('product')->select('id')->where('name',$product)->get();
    		DB::table('sold_products')->insert([
    					'product_id' => $id[0]->id,
    					'seller_id' => $uid,
    				]);
    		return redirect('/products')->with('msg','Item Sold Successfully');

    	}
    }

    public function load_children()
    {
    	$id = DB::table('relation')->select('child_id')->get();
    	$ids = array();
        foreach ($id as $i) {
        	array_push($ids, $i->child_id);
        }
    	$data = DB::table('tbl_users')
    					->select('name','id')
    					->whereNotIn('id',$ids)
    					->get();
    	// echo json_encode($data);
    	return view('children_list',['children' =>$data]);

    }
    
    public function List_children()
    {
    	$uid = session('userID');

    	$id = DB::table('relation')->select('child_id')->where('parent_id',$uid)->get();
    	$limit = intval(request("length"));
        $offset = intval(request("start"));
        $ids = array();
        foreach ($id as $i) {
        	array_push($ids, $i->child_id);
        }

        $data = DB::table('tbl_users')->select('id','name','email','status')->whereIn('id',$ids)->offset($offset)->limit($limit)->get();
    	// print_r($data);

        $count = DB::table('tbl_users')->select('*')->whereIn('id',$ids)->get();

        // echo count($data);
        $response = array(
               "draw" => intval(request("draw")),
               "lenth" => $limit,
               "start" => $offset,
               "iTotalRecords" => count($count),
               "iTotalDisplayRecords" =>count($count),
               "aaData" => $data
            );
        echo json_encode($response);
    }

    public function add_child()
    {
    	$uid = session('userID');

    	$id = DB::table('tbl_users')->select('id')->where('name',request('users'))->get();

    	// print_r($id);
    	DB::table('relation')->insert([
    					'child_id' => $id[0]->id,
    					'parent_id' => $uid,
    				]);

    return redirect('/children')->with('msg','Child Added Successfully');
    }

    public function soldByMe()
    {
    	return view('sold');
    }

    public function revenue()
    {
        $data = DB::table('product')->where('status','sold')->sum('price');
        $id = DB::table('sold_products')->select('product_id')->orderBy('id', 'DESC')->limit('1')->get();
    	$price = DB::table('product')->select('price')->where('id',$id[0]->product_id)->sum('price');
    	return view('revenue',['total' => $data,'last' =>$price]);
    }



    public function sold_products()
    {
    	$uid = session('userID');
    	$limit = intval(request("length"));
        $offset = intval(request("start"));
        $data = DB::table('sold_products')->select('product_id')->where('seller_id',$uid)->get();
         $ids = array();
        foreach ($data as $i) {
        	array_push($ids, $i->product_id);
        }

        $product = DB::table('product')->select('id','name','price','status')->whereIn('id',$ids)->get();
        $count = DB::table('product')->select('*')->whereIn('id',$ids)->get();
        $response = array(
               "draw" => intval(request("draw")),
               "lenth" => $limit,
               "start" => $offset,
               "iTotalRecords" => count($count),
               "iTotalDisplayRecords" =>count($count),
               "aaData" => $product
            );
        echo json_encode($response);

    }
    public function load_revenue()
    {
    	$limit = intval(request("length"));
        $offset = intval(request("start"));
        $data = DB::table('sold_products')->select('product_id')->get();
         $ids = array();
        foreach ($data as $i) {
        	array_push($ids, $i->product_id);
        }

        $product = DB::table('product')->select('id','name','price','status','timestamp')->whereIn('id',$ids)->get();
        $response = array(
               "draw" => intval(request("draw")),
               "lenth" => $limit,
               "start" => $offset,
               "iTotalRecords" => count($product),
               "iTotalDisplayRecords" =>count($product),
               "aaData" => $product
            );
        echo json_encode($response);
    	// return view('revenue');

    }

    public function Date_filter(Request $req)
    {

    	$start = date("Y-m-d h:i:s", strtotime(request('start')));
    	$end = date("Y-m-d h:i:s", strtotime(request('end')));
        // $data = DB::table('product')->select('timestamp')->where('id',1)->get();
        $data = DB::table('product')->select('id','name','price','status','timestamp')->where('status','sold')->whereBetween('timestamp', [$start, $end])->get();
        // // return User_chat::find(request('id'))->delete();
        echo json_encode($data);
    }

    

}

