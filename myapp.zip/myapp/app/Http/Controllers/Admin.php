<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Admin extends Controller
{
    public function admin()
    {
        return view('admin/login');
    }
    
    public function admin_welcome()
    {
    	// echo base_path('js\123');    // '/var/www/mysite'

        return view('admin/welcome');

    }
    
     public function login(Request $req)
    {
    	$email =  request('email_id');
    	$pass =  md5(request('password'));
    	$data = DB::table('admin')->where('email', $email)->where('password', $pass)->get();
    	if($data->count() > 0)
    	{
            $req->session()->put('AdminID',$data[0]->id);
        	$req->session()->put('AdminName',$data[0]->name);
    		return redirect('/admin-welcome')->with('msg','Login Successfull');
    	}
    	else
    	{
    		echo 'false';
    		return redirect('/admin')->with('msg','Incorrect User Id and Password');

    	}
    	
    }
    public function products()
    {
        return view('admin/products');
    }
    public function relation()
    {
        return view('admin/relation');
    }
    public function addProducts()
    {
        // echo request('name');
        // echo request('price');
        DB::table('product')->insert([
                        'name' => request('name'),
                        'price' => request('price'),
                        'status' => 'available',
                    ]);
        return view('admin/products');
    }
    public function list_parent()
    {
        $id = DB::table('relation')->select('parent_id')->get();
        $limit = intval(request("length"));
        $offset = intval(request("start"));
        $ids = array();
        foreach ($id as $i) {
            array_push($ids, $i->parent_id);
        }

        $fids = array_unique($ids,SORT_STRING);

        $parentdata = DB::table('tbl_users')->select('id','name','email','status')->whereIn('id',$fids)->get();
        // print_r($parentdata);


        foreach ($parentdata as $d) 
        {
            $childid = DB::table('relation')
                            ->select('child_id')
                            ->where('parent_id',$d->id)
                            ->get();

            $cids = array();
            foreach ($childid as $i) {
                array_push($cids, $i->child_id);
            }    
            $childdata = DB::table('tbl_users')
                            ->select('id','name','email','status')
                            ->whereIn('id',$cids)
                            ->get();
            $d->child = $childdata;
            }
        //  

        $count = DB::table('tbl_users')->select('*')->whereIn('id',$fids)->get();
        // // echo count($data);
        $response = array(
               "draw" => intval(request("draw")),
               "lenth" => $limit,
               "start" => $offset,
               "iTotalRecords" => count($count),
               "iTotalDisplayRecords" =>count($count),
               "aaData" => $parentdata
            );
        echo json_encode($response);
    }

}
