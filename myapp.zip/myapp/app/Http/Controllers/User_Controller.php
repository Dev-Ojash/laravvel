<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\DB;
use Mail;

use App\User_chat;

class User_Controller extends Controller
{

    public function show(Request $req)
    {
    	//MODEL
    	// $data = User_chat::all();
    	// $data = User_chat::orderBy('email','desc')->get();
    	// $data = User_chat::where('name','ojash')->get();
    	// $data = User_chat::lattest()->get();
    	// $data = User_chat::findOrFail(1);



    	//SESSION
    	// $req->session()->put('key','patel');
    	// $req->session()->forget('key');
    	// $val = $req->session()->get('key');
    	


    	//PRINT DATA
    	// echo json_encode($data);
    	// print_r($data);
    	// foreach ($data as $d) {
    	// 		echo $d->id." ";
    	// 		echo $d->name." ";
    	// 		echo $d->email." ";
    	// 		echo $d->password."<br>";
    	// }

    			// echo $data->id." ";
    			// echo $data->name." ";
    			// echo $data->email." ";
    			// echo $data->password."<br>";
    	
        // return view('login',['name' => $val]);
        // $response->withCookie(cookie('userID', 1, 1));
        // echo Cookie::get('userID');
    	// return view('temp');
        // DB::insert('insert into tbl_users (email, name,password) values (7, 7,7)');
        // $data = DB::select('select * from tbl_users');

        // echo json_encode($data);

        echo base_path('js\123');    // '/var/www/mysite'
        // echo app_path();     // '/var/www/mysite/app'
        // echo storage_path();



    }
    public function index(Request $req)
    {
        return view('login');
    }

    public function users()
    {
    	return view('users');
    }


    public function load_reg()
    {
    	return view('regestration');

    }

    public function load_welcome()
    {
    	return view('welcome');

    }

    public function load_login()
    {
    	return view('login');
    }

    public function logout(Request $req)
    {
    	$req->session()->flush();
        // setcookie('emailID','',time() - 160,'/');
        // setcookie('password','',time() - 160,'/');
    	return redirect('/');
    }
    public function hello()
    {
        echo 'hello';
    }

    // public function list_users()
    // {
    //     $data = User_chat::select('id','name','email','status')->get();
    //     // print_r($data[0]);
    //     echo json_encode($data);

    // }
    


    public function login(Request $req)
    {
    	$email =  request('email_id');
    	$pass =  md5(request('password'));

    	$data = User_chat::where('email', $email)->where('password', $pass)->get();
    	// $data = User_chat::where('email', 'mail@mail.com')->where('password', '12345')->get();
    	// if($data)
    	if($data->count() > 0)
    	{
         
            $req->session()->put('userID',$data[0]->id);
        	$req->session()->put('username',$data[0]->name);
         //    $response = new Response('1');
         //    $response->withCookie(cookie('userID',$data[0]->id, 1));
            // $this->load_welcome();
            setcookie('emailID',$email,time() + 1600,'/');
            setcookie('password',request('password'),time() + 1600,'/');
            // print_r($_COOKIE);
    		return redirect('/welcome')->with('msg','Login Successfull');
            // return $response;



    	}
    	else
    	{
    		echo 'false';
    		return redirect('/')->with('msg','Incorrect User Id and Password');

    	}
    	
    }
    public function regester()
    {
    	$name =  request('userName');
    	$email =  request('emailId');
    	$pass =  md5(request('password'));
    	$data = User_chat::where('email', $email)->get();
    	// $data = User_chat::where('email', 'mail@mail.com')->where('password', '12345')->get();
    	// if($data)
    	if($data->count() > 0)
    	{
    		return redirect('/regestration')->with('msg','Email id is already exist');
    	}
    	else
    	{
            $maildata = DB::table('emailed')->where('email', $email)->get();
            if($maildata->count() > 0)
            {
                $user = new User_chat();
                $user->name = $name; 
                $user->email = $email; 
                $user->password = $pass;
                $user->save(); 
                $newid = $user->id;
                $pid = $maildata[0]->reference_id;
                DB::table('emailed')->where('email',$email)->delete();
                $totalid = DB::table('relation')->select('child_id')->where('parent_id',$pid)->get();
                if(count($totalid) >= 2)
                {
                    return redirect('/')->with('msg','New Regestration Successfull.');
                }
                else
                {
                    DB::table('relation')->insert([
                            'child_id' => $newid,
                            'parent_id' => $pid,
                        ]);
                    return redirect('/')->with('msg','Refer Regestration Successfull.');
                }



            }
            else
            {
        		$user = new User_chat();
        		$user->name = $name; 
        		$user->email = $email; 
        		$user->password = $pass;
        		$user->save(); 
                return redirect('/')->with('msg','New Regestration Successfull.');
            }



    	}
    }
    public function profile()
    {
        $uid = session('userID');
        $data = User_chat::where('id', $uid)->get();
        $data2 = User_chat::select('total_amount', 'last_amount')->where('id',$uid)->get();
        $ans = ['name' => $data[0]->name,
                'email' => $data[0]->email,
                'total_amount' => $data[0]->total_amount,
                'last_amount' => $data[0]->last_amount,
         ];
        // print_r($ans);
        return view('profile',$ans);
    }

    public function editProfile()
    {
        $uid = session('userID');
        $old = User_chat::select('password')->where('id', $uid)->get();
        // echo md5(request('old_password'));
        // echo "<br>";
        // echo $old[0]->password;
        // echo "<br>";

        if(md5(request('old_password')) != $old[0]->password)
        {
            echo ' ';
            // return redirect('/profile');
            // print_r(request('user_name'));
        }
        else
        {
            $user = User_chat::find($uid);
            $user->name = request('user_name');
            $user->email = request('user_email');
            $user->password = md5(request('new_password'));
            $user->save();
            return redirect('/profile');


        }


        // return view('profile',$ans);
    }
    
    public function list_users()
    {
        $limit = intval(request("length"));
        $offset = intval(request("start"));

        $data = User_chat::select('id','name','email','status')->offset($offset)->limit($limit)->get();
        $count = User_chat::select('*')->get();

        // echo count($data);
        $response = array(
               "draw" => intval(request("draw")),
               "lenth" => $limit,
               "start" => $offset,
               "iTotalRecords" => count($count),
               "iTotalDisplayRecords" =>count($count),
               "aaData" => $data
            );
        echo json_encode($response);
    }

    public function del(Request $req)
    {
        // echo request('id');
        return User_chat::find(request('id'))->delete();

    }
   

    public function filter(Request $req)
    {
        $data = User_chat::select('id','name','email','status')->Where('email', 'like', request('email') . '%')->get();
        // return User_chat::find(request('id'))->delete();
        echo json_encode($data);
    }

    public function referToFrd()
    {
        $uid = session('userID');
        $noofChild = DB::table('relation')->where('parent_id',$uid)->get();
        $email = request('email');
        $name = request('name');
        $uname = User_chat::where('id',$uid)->get();
        $existEmail = User_chat::where('email',$email)->get();
        $emailed = DB::table('emailed')->where('email',$email)->get();
        if(count($noofChild) >= 2)
        {
            return redirect('/profile')->with('msg','You Already Have 2 Childrens!');
        }
        elseif(count($existEmail) > 0)
        {
            return redirect('/profile')->with('msg','Email Id Already Exist!');
        }
        elseif(count($emailed) > 0)
        {
            return redirect('/profile')->with('msg','Email Already Sent!');
        }
        else
        {
            $mail = DB::table('emailed')->insert([
                        'name' => $name,
                        'email' => $email,
                        'reference_id' =>$uid
                    ]);
            $data = ['name' => $name, 'uname' => $uname[0]->name];
            $user['to'] = $email;
            Mail::send('mail',$data,function($message) use ($user)
            {
                $message->to($user['to']);
                $message->subject('hello ');
            });
            return redirect('/profile')->with('msg','Email Sent Successfully!');

        }

    }



    
}
