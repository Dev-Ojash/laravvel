<?php
use App\Http\Controllers\User_Controller;
use App\Http\Controllers\products;
use App\Http\Controllers\Admin;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
// */
// Route::get('/',function()
// {			
// 	return view('login');

// });
//GET METHODS
Route::get('/', [User_Controller::class, 'load_login']);
Route::get('/login', [User_Controller::class, 'load_login']);
Route::get('/regestration', [User_Controller::class, 'load_reg']);
Route::get('/logout', [User_Controller::class, 'logout']);
Route::get('/admin', [Admin::class, 'admin']);


//POST METHODS
Route::post('/login', [User_Controller::class, 'login']);
Route::post('/regestration', [User_Controller::class, 'regester']);
Route::post('/admin', [Admin::class, 'login']);



//MIDDLEWARE
Route::middleware(['user_auth'])->group(function () {
	
	//MIDDLEWARE GET METHODS
	Route::get('/welcome', [User_Controller::class, 'load_welcome']);
	Route::get('/profile', [User_Controller::class, 'profile']);
	Route::get('/products', [products::class, 'products']);
	Route::get('/sell', [products::class, 'load_sell_products']);
	Route::get('/children', [products::class, 'load_children']);
	Route::get('/soldByMe', [products::class, 'soldByme']);
	Route::get('/mail', [products::class, 'index']);



	//MIDDLEWARE POST METHODS
	Route::post('/profile', [User_Controller::class, 'editProfile']);
	Route::post('/del_users', [User_Controller::class, 'del']);
	Route::post('/filterByemail', [User_Controller::class, 'filter']);
	Route::post('/products', [products::class, 'list_products']);
	Route::post('/sellproduct', [products::class, 'sell_product']);
	Route::post('/children', [products::class, 'list_children']);
	Route::post('/addchild', [products::class, 'add_child']);
	Route::post('/soldByMe', [products::class, 'sold_products']);
	Route::post('/refer', [User_Controller::class, 'referToFrd']);
});


//MIDDLEWARE
Route::middleware(['Admin_auth'])->group(function () {
	
	//MIDDLEWARE GET METHODS
	Route::get('/users', [User_Controller::class, 'users']);
	Route::get('/show', [User_Controller::class, 'show']);
	Route::get('/revenue', [products::class, 'revenue']);
	Route::get('/admin-welcome', [Admin::class, 'admin_welcome']);
	Route::get('/all-products', [Admin::class, 'products']);
	Route::get('/addProducts', [Admin::class, 'temp']);
	Route::get('/Relationship', [Admin::class, 'relation']);



	//MIDDLEWARE POST METHODS
	Route::post('/users', [User_Controller::class, 'list_users']);
	Route::post('/revenue', [products::class, 'load_revenue']);
	Route::post('/filterByDate', [products::class, 'Date_filter']);
	Route::post('/addProducts', [Admin::class, 'addProducts']);
	Route::post('/parents', [Admin::class, 'list_parent']);
});


// Route::get('/setcookie', [cookies::class, 'setCookie']);
// Route::get('/getcookie', [cookies::class, 'getCookie']);
// Route::get('/delcookie', [cookies::class, 'delCookie']);
//POST METHODS

