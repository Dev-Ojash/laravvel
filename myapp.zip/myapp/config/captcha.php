<?php

return [
    // 'secret' => env('NOCAPTCHA_SECRET'),
    // 'sitekey' => env('NOCAPTCHA_SITEKEY'),
    'secret' => env('6Ld1c88aAAAAAF3FgKCI1e6UD2vlqmzJt_ebh76h'),
    'sitekey' => env('6Ld1c88aAAAAACAb4_nQHPs2HU21ha8imCCjCQ'),
    'options' => [
        'timeout' => 30,
    ],
];
